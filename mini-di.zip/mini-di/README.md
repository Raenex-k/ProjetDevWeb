# mini-di : un conteneur d'injection de dependances from scratch

Ce projet est un **mini-framework** qui reproduit le coeur de Spring : l'injection
de dependances par annotations. Le but est pedagogique : comprendre **comment Spring
fonctionne reellement en interne** quand tu ecris `@Component` et `@Autowired` dans
ton stage.

Tout tient en quelques centaines de lignes, sans aucune librairie externe, juste avec
la **reflexion** native de Java.

---

## Ce que ca fait

Exactement ce que fait Spring a son demarrage :

1. **Scanner** un package pour trouver les classes annotees `@Component`
2. **Instancier** chacune de ces classes (les "beans")
3. **Injecter** automatiquement les dependances entre elles (via `@Autowired`)
4. **Stocker** les beans en singletons et les fournir via `getBean(...)`

Tu ecris ton code metier avec des annotations, et le conteneur fait toute la
"tuyauterie" a ta place. **Tu ne fais plus aucun `new`.**

---

## La structure du projet

```
mini-di/
├── pom.xml                          Configuration Maven (zero dependance)
├── README.md                        Ce fichier
└── src/main/java/com/minidi/
    ├── annotations/
    │   ├── Component.java           Marqueur "ceci est un bean" (= @Component Spring)
    │   └── Autowired.java           Marqueur "injecte mes dependances" (= @Autowired Spring)
    ├── exceptions/
    │   └── DependencyInjectionException.java   Erreur unique du conteneur
    ├── core/
    │   ├── ClasspathScanner.java    Trouve les @Component dans un package
    │   └── ApplicationContext.java  LE CONTENEUR : cree et cable les beans
    └── example/
        ├── GreetingRepository.java  Couche Repository (imite ton projet CACF)
        ├── GreetingService.java     Couche Service (depend du Repository)
        ├── GreetingResource.java    Couche Resource (depend du Service)
        └── Main.java                Lance la demo
```

L'exemple imite **exactement l'architecture de ton API Happy** :

```
GreetingResource  ->  GreetingService  ->  GreetingRepository
   (couche HTTP)        (couche metier)       (couche donnees)
```

---

## Les 3 concepts cles a comprendre

### 1. L'inversion de controle (IoC)

Normalement, c'est **ton** code qui cree ses objets :

```java
GreetingRepository repo = new GreetingRepository();
GreetingService service = new GreetingService(repo);
GreetingResource resource = new GreetingResource(service);
```

Avec le conteneur, c'est **lui** qui fait tout ca, dans le bon ordre. Le controle
est "inverse" : tu ne crees plus rien, tu declares juste tes besoins. C'est le
principe fondamental de Spring.

### 2. La reflexion

La reflexion, c'est la capacite de Java a **lire et manipuler du code a l'execution** :
lire les annotations d'une classe, lister ses constructeurs, les appeler dynamiquement.

C'est ce qui rend tout possible. Sans reflexion, impossible de detecter `@Component`
ou d'appeler un constructeur dont on ne connait pas les parametres a l'avance.

Le detail crucial : les annotations doivent etre en `@Retention(RUNTIME)` pour rester
lisibles a l'execution. Sinon elles sont effacees a la compilation.

### 3. Le singleton

Chaque bean n'est cree **qu'une seule fois** et reutilise partout. Si deux classes
ont besoin du meme repository, elles recoivent **la meme instance**. C'est le
comportement par defaut de Spring aussi.

---

## Comment lancer le projet

### En ligne de commande

```bash
# 1. Compiler
mkdir -p target/classes
javac -d target/classes $(find src -name "*.java")

# 2. Lancer
java -cp target/classes com.minidi.example.Main
```

### Dans IntelliJ

1. Ouvrir le dossier `mini-di` comme projet Maven (via le `pom.xml`)
2. Clic droit sur `Main.java` -> Run

---

## Ce que tu verras s'afficher

```
=== Demarrage du conteneur ===
Scan du package : com.minidi.example
  [scan] Composant detecte : com.minidi.example.GreetingRepository
  [scan] Composant detecte : com.minidi.example.GreetingResource
  [scan] Composant detecte : com.minidi.example.GreetingService
Nombre de composants trouves : 3
--- Creation des beans ---
    [cree] GreetingRepository
    -> GreetingResource a besoin de GreetingService
    -> GreetingService a besoin de GreetingRepository
    [cree] GreetingService
    [cree] GreetingResource
=== Conteneur pret. 3 beans actifs. ===

--- Test d'utilisation ---
Resultat : Bonjour depuis le Repository, Rayane !

--- Verification singleton ---
Meme instance que la 1ere fois ? true
```

Observe l'ordre de creation : le conteneur cree le **Repository d'abord** (il n'a pas
de dependance), puis le **Service** (qui a besoin du repo), puis la **Resource** (qui a
besoin du service). Il resout l'arbre tout seul. C'est exactement ce que fait Spring.

---

## L'ordre de lecture conseille

Pour bien comprendre, lis les fichiers dans cet ordre :

1. `annotations/Component.java` et `annotations/Autowired.java` (les marqueurs)
2. `example/` (les classes metier simples : Repository, Service, Resource)
3. `core/ClasspathScanner.java` (comment on trouve les @Component)
4. `core/ApplicationContext.java` (le coeur : comment on cree et cable les beans)
5. `example/Main.java` (la demonstration finale)

Chaque fichier est abondamment commente pour expliquer le "pourquoi" a chaque etape.

---

## Pour aller plus loin (defis pour toi)

Une fois que tu maitrises ce code, essaie d'ajouter ces fonctionnalites, dans
l'ordre de difficulte :

1. **Injection par champ** : supporter `@Autowired` directement sur un attribut
   (pas seulement sur le constructeur), comme le permet Spring.
2. **Beans nommes** : `@Component("monNom")` et `getBean("monNom")`.
3. **Scope prototype** : une annotation `@Prototype` qui cree une NOUVELLE instance
   a chaque demande, au lieu d'un singleton.
4. **Methodes @PostConstruct** : appeler une methode d'initialisation apres
   l'injection, comme le cycle de vie des beans Spring.
5. **Gestion des .jar** : faire fonctionner le scanner meme quand les classes sont
   dans un fichier .jar (et pas seulement dans des dossiers).
6. **Mini-routeur HTTP** : ajouter des annotations `@Get("/chemin")` et un petit
   serveur, pour transformer ce conteneur en mini-Spring-Boot complet.

Chacun de ces defis t'apprendra une brique de plus d'un vrai framework.

---

## Le lien avec ton stage

Chaque fois que tu ecris dans ton API Happy :

```java
@Service
public class GeoLocationService {
    @Autowired
    public GeoLocationService(GeoLocationRepository repository) { ... }
}
```

... Spring fait EXACTEMENT ce que fait ce mini-projet : il scanne, trouve ta classe,
lit le constructeur, cree le repository, et te l'injecte. Tu sais maintenant ce qui
se passe "sous le capot". C'est ca, comprendre un framework de l'interieur.
