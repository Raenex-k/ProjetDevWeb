package com.minidi.exceptions;

/**
 * ============================================================================
 *  DependencyInjectionException
 * ============================================================================
 *
 * Une exception unique pour tous les problemes du conteneur :
 *   - une dependance introuvable (pas de bean du bon type)
 *   - une dependance circulaire (A a besoin de B qui a besoin de A)
 *   - un echec d'instanciation (constructeur qui plante, classe abstraite...)
 *
 * On herite de RuntimeException (exception "unchecked") volontairement :
 *   -> pas besoin de "throws" partout, l'erreur remonte toute seule.
 *   C'est exactement ce que fait Spring avec sa BeanCreationException.
 *
 * (Rappel du cours qu'on a fait : unchecked = pas de try/catch ni throws
 *  obliges ; l'exception remonte jusqu'a celui qui veut bien la gerer.)
 * ============================================================================
 */
public class DependencyInjectionException extends RuntimeException {

    public DependencyInjectionException(String message) {
        super(message);
    }

    // Ce 2e constructeur garde la "cause" d'origine (l'exception initiale).
    // Tres utile pour le debug : on voit l'erreur reelle ET notre message clair.
    public DependencyInjectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
