package com.minidi.example;

import com.minidi.annotations.Autowired;
import com.minidi.annotations.Component;

/**
 * ============================================================================
 *  GreetingResource  --  imite la couche Resource (HTTP) de ton projet CACF
 * ============================================================================
 *
 * Niveau le plus haut de la chaine de dependances :
 *
 *      GreetingResource  ->  GreetingService  ->  GreetingRepository
 *
 * Quand le conteneur veut creer ce Resource, il doit d'abord creer le Service,
 * qui lui-meme a besoin du Repository. Le conteneur resout donc tout l'arbre
 * de bas en haut, automatiquement, grace a la recursivite de getOrCreateBean.
 *
 * C'est EXACTEMENT le schema de ton API Happy : la Resource appelle le Service,
 * jamais le Repository directement. Ici, GreetingResource ne connait meme pas
 * l'existence du Repository.
 * ============================================================================
 */
@Component
public class GreetingResource {

    private final GreetingService service;

    @Autowired
    public GreetingResource(GreetingService service) {
        this.service = service;
        System.out.println("      (GreetingResource construit avec son service injecte)");
    }

    /**
     * Simule la reception d'une requete HTTP : on delegue au service.
     * (Dans ton projet, ce serait une methode annotee @GET / @POST.)
     */
    public String handleRequest(String name) {
        return service.buildGreeting(name);
    }
}
