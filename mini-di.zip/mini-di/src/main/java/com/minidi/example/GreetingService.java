package com.minidi.example;

import com.minidi.annotations.Autowired;
import com.minidi.annotations.Component;

/**
 * ============================================================================
 *  GreetingService  --  imite la couche Service de ton projet CACF
 * ============================================================================
 *
 * Cette classe DEPEND de GreetingRepository. C'est le coeur de la demo :
 * on ne fait JAMAIS "new GreetingRepository()" ici. A la place :
 *
 *   - le constructeur DECLARE qu'il a besoin d'un GreetingRepository
 *   - le @Autowired dit au conteneur "fournis-moi cette dependance"
 *   - le conteneur cree d'abord le repository, puis nous le passe
 *
 * Le champ est "final" : une fois injecte, il ne change plus. C'est la garantie
 * d'immuabilite qu'offre l'injection par constructeur (bonne pratique Spring).
 * ============================================================================
 */
@Component
public class GreetingService {

    // La dependance. "final" = obligatoire et jamais modifiee apres construction.
    private final GreetingRepository repository;

    /**
     * Constructeur injecte par le conteneur.
     *
     * Quand le conteneur voit @Autowired, il regarde les parametres
     * (ici : GreetingRepository), va chercher/creer ce bean, et le passe ici.
     * Nous, on se contente de le stocker.
     */
    @Autowired
    public GreetingService(GreetingRepository repository) {
        this.repository = repository;
        System.out.println("      (GreetingService construit avec son repository injecte)");
    }

    /**
     * Logique metier : recupere la donnee du repository et la transforme.
     * Exactement le role d'un Service : orchestrer, pas acceder a la BDD lui-meme.
     */
    public String buildGreeting(String name) {
        String base = repository.findGreeting(); // on utilise la dependance injectee
        return base + ", " + name + " !";
    }
}
