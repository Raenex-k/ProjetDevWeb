package com.minidi.example;

import com.minidi.core.ApplicationContext;

/**
 * ============================================================================
 *  Main  --  le point d'entree qui demontre tout le mini-framework
 * ============================================================================
 *
 * Ce qu'on prouve ici :
 *
 *   1. On ne fait AUCUN "new GreetingRepository()", "new GreetingService()",
 *      "new GreetingResource()". Pourtant, tout fonctionne.
 *      -> C'est le conteneur qui a tout cree et tout cable. C'est ca la magie
 *         de l'injection de dependances, et c'est ce que fait Spring.
 *
 *   2. On demande juste le bean du HAUT de la chaine (GreetingResource), et
 *      toutes ses dependances ont deja ete injectees pour nous.
 *
 *   3. Le bean est un SINGLETON : si on le redemande, c'est la meme instance.
 * ============================================================================
 */
public class Main {

    public static void main(String[] args) {

        // --- 1. Demarrer le conteneur sur notre package d'exemple -----------
        // C'est l'equivalent de :
        //   new AnnotationConfigApplicationContext("com.minidi.example") en Spring
        ApplicationContext context = new ApplicationContext("com.minidi.example");

        // --- 2. Recuperer le bean du haut de la chaine ----------------------
        // On ne demande QUE la Resource. Son Service et son Repository ont deja
        // ete crees et injectes automatiquement par le conteneur.
        GreetingResource resource = context.getBean(GreetingResource.class);

        // --- 3. Utiliser le bean comme si on l'avait cable a la main ---------
        System.out.println("--- Test d'utilisation ---");
        String result = resource.handleRequest("Rayane");
        System.out.println("Resultat : " + result);

        // --- 4. Prouver le comportement SINGLETON ---------------------------
        // On redemande le meme bean : ce doit etre EXACTEMENT la meme instance.
        GreetingResource resource2 = context.getBean(GreetingResource.class);
        System.out.println("\n--- Verification singleton ---");
        System.out.println("Meme instance que la 1ere fois ? " + (resource == resource2));

        // --- 5. Lister tous les beans actifs --------------------------------
        System.out.println("\n--- Beans geres par le conteneur ---");
        for (String name : context.getBeanNames()) {
            System.out.println("  - " + name);
        }
    }
}
