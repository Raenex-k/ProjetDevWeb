package com.minidi.example;

import com.minidi.annotations.Component;

/**
 * ============================================================================
 *  GreetingRepository  --  imite la couche Repository de ton projet CACF
 * ============================================================================
 *
 * Le @Component dit au conteneur : "cree une instance de moi au demarrage".
 *
 * Cette classe n'a AUCUNE dependance : son constructeur est vide (implicite).
 * C'est donc une "feuille" de l'arbre de dependances -> le conteneur peut la
 * creer en premier, sans rien resoudre avant.
 *
 * Dans la vraie vie (ton API Happy), ce serait une classe qui parle a la base
 * SQL Server. Ici, on simule juste en retournant du texte.
 * ============================================================================
 */
@Component
public class GreetingRepository {

    /**
     * Simule un acces aux donnees : renvoie un message stocke.
     * Dans ton projet, ce serait un SELECT en base.
     */
    public String findGreeting() {
        return "Bonjour depuis le Repository";
    }
}
