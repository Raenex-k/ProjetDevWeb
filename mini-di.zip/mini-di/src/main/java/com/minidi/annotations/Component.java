package com.minidi.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * ============================================================================
 *  @Component  --  l'equivalent du @Component / @Service de Spring
 * ============================================================================
 *
 * Cette annotation est un simple "marqueur". On la pose au-dessus d'une classe
 * pour dire au conteneur : "cette classe est un bean, instancie-la et gere-la".
 *
 * Une annotation en Java ne FAIT rien toute seule. C'est juste une etiquette
 * (une metadonnee) collee sur le code. C'est le conteneur qui, plus tard, va
 * SCANNER les classes, detecter celles qui portent cette etiquette, et agir.
 *
 * Les deux meta-annotations en dessous sont fondamentales :
 *
 *   @Retention(RUNTIME)
 *      -> dit a la JVM de GARDER l'annotation jusqu'a l'execution.
 *      Par defaut, les annotations sont effacees a la compilation. Si on ne met
 *      pas RUNTIME, notre conteneur ne pourrait JAMAIS la lire par reflexion.
 *      C'est LE point cle qui rend tout le systeme possible.
 *
 *   @Target(TYPE)
 *      -> dit que cette annotation ne peut etre posee QUE sur une classe (TYPE),
 *      pas sur un champ ou une methode. Le compilateur refusera tout mauvais usage.
 * ============================================================================
 */
@Retention(RetentionPolicy.RUNTIME) // l'annotation survit jusqu'a l'execution -> lisible par reflexion
@Target(ElementType.TYPE)           // utilisable uniquement sur une classe / interface
public @interface Component {
    // Vide : c'est juste un marqueur. Pas besoin d'attributs.
    // (Spring permet @Component("nom") ; on garde simple ici.)
}
