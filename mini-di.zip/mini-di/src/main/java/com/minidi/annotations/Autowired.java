package com.minidi.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * ============================================================================
 *  @Autowired  --  l'equivalent exact du @Autowired de Spring
 * ============================================================================
 *
 * On pose cette annotation sur un CONSTRUCTEUR pour dire au conteneur :
 * "pour creer ce bean, tu dois d'abord me fournir tous les parametres de ce
 *  constructeur ; va les chercher dans tes beans deja crees".
 *
 * C'est le coeur de l'injection de dependances :
 *   - la classe ne cree PAS elle-meme ses dependances (pas de "new ...")
 *   - elle DECLARE ce dont elle a besoin (via les parametres du constructeur)
 *   - le conteneur les lui FOURNIT
 *
 * On a choisi l'injection par CONSTRUCTEUR (et pas par champ) car c'est la
 * bonne pratique recommandee, meme par Spring :
 *   - les dependances sont visibles et obligatoires
 *   - le bean est immuable (champs "final")
 *   - c'est testable sans conteneur (on peut appeler "new" a la main dans un test)
 *
 * @Target(CONSTRUCTOR) -> cette annotation se pose uniquement sur un constructeur.
 * @Retention(RUNTIME)  -> elle reste lisible a l'execution (indispensable).
 * ============================================================================
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.CONSTRUCTOR) // se pose sur un constructeur
public @interface Autowired {
}
