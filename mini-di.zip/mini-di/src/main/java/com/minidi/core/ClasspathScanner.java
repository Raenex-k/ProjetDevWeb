package com.minidi.core;

import com.minidi.annotations.Component;
import com.minidi.exceptions.DependencyInjectionException;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 *  ClasspathScanner  --  l'equivalent du "component scanning" de Spring
 * ============================================================================
 *
 * Role : parcourir un package donne (ex: "com.minidi.example"), trouver TOUTES
 * les classes, et ne garder que celles annotees avec @Component.
 *
 * C'est exactement ce que fait Spring au demarrage quand il affiche
 * "scanning for components in package ...". On reproduit cette magie ici.
 *
 * Comment on trouve les classes d'un package ?
 *   1. On transforme le nom du package "com.minidi.example" en chemin de
 *      dossier "com/minidi/example".
 *   2. On demande au ClassLoader OU se trouve ce dossier sur le disque
 *      (dans le classpath, c-a-d le dossier "target/classes" en general).
 *   3. On liste les fichiers .class de ce dossier.
 *   4. Pour chaque .class, on reconstruit le nom complet de la classe et on la
 *      charge avec Class.forName(...).
 *   5. On regarde si elle porte @Component. Si oui, on la garde.
 *
 * NOTE pedagogique : un vrai framework gere aussi les classes DANS des .jar
 * (fichiers zippes) et les sous-packages recursivement. Ici on reste sur le cas
 * simple "classes dans des dossiers" pour que le code reste lisible.
 * ============================================================================
 */
public class ClasspathScanner {

    /**
     * Scanne un package et retourne la liste des classes annotees @Component.
     *
     * @param basePackage ex: "com.minidi.example"
     * @return la liste des classes a transformer en beans
     */
    public List<Class<?>> findComponents(String basePackage) {
        List<Class<?>> components = new ArrayList<>();

        // --- Etape 1 : nom de package -> chemin de dossier ---------------------
        // "com.minidi.example" devient "com/minidi/example"
        // On remplace chaque point par un separateur de dossier.
        String path = basePackage.replace('.', '/');

        // --- Etape 2 : demander au ClassLoader ou est ce dossier ---------------
        // Le ClassLoader est l'objet de la JVM qui sait ou sont les classes.
        // getResource(path) nous donne l'URL physique du dossier sur le disque.
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        URL resource = classLoader.getResource(path);

        if (resource == null) {
            throw new DependencyInjectionException(
                "Package introuvable dans le classpath : " + basePackage);
        }

        // L'URL ressemble a "file:/.../target/classes/com/minidi/example"
        // On la transforme en vrai dossier manipulable.
        File directory = new File(resource.getFile());

        if (!directory.exists()) {
            throw new DependencyInjectionException(
                "Le dossier du package n'existe pas : " + directory.getAbsolutePath());
        }

        // --- Etape 3 : parcourir les fichiers du dossier -----------------------
        scanDirectory(directory, basePackage, components);

        return components;
    }

    /**
     * Parcourt un dossier (et ses sous-dossiers) a la recherche de fichiers .class.
     * Methode recursive : si elle trouve un sous-dossier, elle s'appelle elle-meme.
     */
    private void scanDirectory(File directory, String packageName, List<Class<?>> components) {
        File[] files = directory.listFiles();
        if (files == null) {
            return; // dossier vide ou illisible
        }

        for (File file : files) {

            if (file.isDirectory()) {
                // --- Cas sous-dossier : on descend dedans (recursivite) --------
                // Le package du sous-dossier = package actuel + "." + nom du dossier
                String subPackage = packageName + "." + file.getName();
                scanDirectory(file, subPackage, components);

            } else if (file.getName().endsWith(".class")) {
                // --- Cas fichier .class : on le transforme en classe Java -------

                // "MonService.class" -> "MonService"
                String simpleName = file.getName().replace(".class", "");

                // nom complet = package + "." + nom simple
                // ex : "com.minidi.example.MonService"
                String fullClassName = packageName + "." + simpleName;

                try {
                    // --- Etape 4 : charger reellement la classe en memoire -----
                    // Class.forName demande a la JVM de charger cette classe.
                    Class<?> clazz = Class.forName(fullClassName);

                    // --- Etape 5 : porte-t-elle l'annotation @Component ? ------
                    // isAnnotationPresent lit les metadonnees de la classe.
                    // C'est possible UNIQUEMENT parce que @Component est en
                    // @Retention(RUNTIME). Sinon, l'annotation serait deja effacee.
                    if (clazz.isAnnotationPresent(Component.class)) {
                        components.add(clazz);
                        System.out.println("  [scan] Composant detecte : " + fullClassName);
                    }

                } catch (ClassNotFoundException e) {
                    // On enveloppe l'exception technique dans la notre, plus claire.
                    throw new DependencyInjectionException(
                        "Impossible de charger la classe : " + fullClassName, e);
                }
            }
        }
    }
}
