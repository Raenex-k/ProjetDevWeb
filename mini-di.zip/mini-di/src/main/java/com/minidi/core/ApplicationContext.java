package com.minidi.core;

import com.minidi.annotations.Autowired;
import com.minidi.exceptions.DependencyInjectionException;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ============================================================================
 *  ApplicationContext  --  LE CONTENEUR (le coeur du mini-framework)
 * ============================================================================
 *
 * C'est l'equivalent de l'ApplicationContext de Spring. C'est lui qui :
 *
 *   1. Lance le scan du package (via ClasspathScanner) pour trouver les @Component
 *   2. Cree une instance de chaque composant (les "beans")
 *   3. Resout automatiquement les dependances (l'injection)
 *   4. Stocke les beans pour pouvoir les redonner avec getBean(...)
 *
 * Concept central : l'INVERSION DE CONTROLE.
 *   - Normalement, TON code fait "new MonService(new MonRepo())".
 *   - Ici, c'est le CONTENEUR qui fait les "new" a ta place, dans le bon ordre,
 *     en branchant les bonnes dependances. Ton code ne fait plus aucun "new".
 *   -> Le controle est "inverse" : ce n'est plus toi qui orchestres, c'est lui.
 *
 * Concept central n.2 : le SINGLETON.
 *   - Chaque bean n'est cree QU'UNE SEULE FOIS et reutilise partout.
 *   - C'est le comportement par defaut de Spring aussi.
 *   - On stocke ces instances uniques dans la map "singletons".
 * ============================================================================
 */
public class ApplicationContext {

    // --- Le "registre" des beans deja crees --------------------------------
    // Cle = le type (la classe), Valeur = l'instance unique (le singleton).
    // Ex : { MonRepository.class -> instance_de_repo, MonService.class -> ... }
    private final Map<Class<?>, Object> singletons = new HashMap<>();

    // La liste de tous les composants trouves par le scan (pas encore instancies).
    private final List<Class<?>> componentClasses;

    // Le scanner qui trouve les @Component dans le package.
    private final ClasspathScanner scanner = new ClasspathScanner();

    // Sert a detecter les dependances circulaires (A -> B -> A).
    // On y note les classes "en cours de creation". Si on retombe sur une classe
    // deja en cours, c'est qu'il y a un cycle infini.
    private final Set<Class<?>> currentlyInCreation = new HashSet<>();

    /**
     * Construit le conteneur et demarre tout le processus.
     *
     * @param basePackage le package a scanner, ex: "com.minidi.example"
     */
    public ApplicationContext(String basePackage) {
        System.out.println("=== Demarrage du conteneur ===");
        System.out.println("Scan du package : " + basePackage);

        // ETAPE 1 : scanner pour trouver toutes les classes @Component.
        this.componentClasses = scanner.findComponents(basePackage);
        System.out.println("Nombre de composants trouves : " + componentClasses.size());

        // ETAPE 2 : instancier chaque composant (avec resolution des dependances).
        System.out.println("--- Creation des beans ---");
        for (Class<?> componentClass : componentClasses) {
            // getOrCreateBean cree le bean s'il n'existe pas encore.
            // (Il peut deja exister s'il a ete cree comme dependance d'un autre.)
            getOrCreateBean(componentClass);
        }

        System.out.println("=== Conteneur pret. " + singletons.size() + " beans actifs. ===\n");
    }

    /**
     * Methode publique : recupere un bean par son type.
     * C'est l'equivalent du context.getBean(MonService.class) de Spring.
     *
     * @param type la classe du bean voulu
     * @return l'instance unique de ce bean
     */
    public <T> T getBean(Class<T> type) {
        Object bean = singletons.get(type);

        if (bean == null) {
            // Le type demande peut etre une INTERFACE. On cherche alors une
            // implementation compatible parmi nos beans.
            bean = findByType(type);
        }

        if (bean == null) {
            throw new DependencyInjectionException(
                "Aucun bean trouve pour le type : " + type.getName());
        }

        // cast() est la version "propre" du cast (T) bean.
        return type.cast(bean);
    }

    /**
     * ========================================================================
     *  LE COEUR DE L'INJECTION : creer un bean et ses dependances
     * ========================================================================
     *
     * C'est une methode RECURSIVE. Pour creer un bean, il faut d'abord creer
     * ses dependances. Et pour creer ces dependances, il faut creer LEURS
     * dependances, etc. La recursivite resout naturellement ce probleme.
     *
     * Exemple : pour creer MonService(MonRepository repo)
     *   -> il faut d'abord un MonRepository
     *   -> donc on appelle getOrCreateBean(MonRepository.class)
     *   -> une fois le repo cree, on cree MonService en lui passant le repo
     */
    private Object getOrCreateBean(Class<?> clazz) {

        // --- Court-circuit singleton --------------------------------------
        // Si le bean existe deja, on le renvoie direct. Pas de double creation.
        if (singletons.containsKey(clazz)) {
            return singletons.get(clazz);
        }

        // --- Detection de dependance circulaire ---------------------------
        // Si cette classe est DEJA en cours de creation et qu'on retombe dessus,
        // c'est un cycle infini (A a besoin de B qui a besoin de A). On stoppe.
        if (currentlyInCreation.contains(clazz)) {
            throw new DependencyInjectionException(
                "Dependance circulaire detectee impliquant : " + clazz.getName());
        }

        // On marque cette classe comme "en cours de creation".
        currentlyInCreation.add(clazz);

        try {
            // --- Etape A : choisir le bon constructeur --------------------
            Constructor<?> constructor = resolveConstructor(clazz);

            // --- Etape B : resoudre chaque parametre du constructeur ------
            // Pour chaque parametre, on recupere (ou cree) le bean correspondant.
            Class<?>[] paramTypes = constructor.getParameterTypes();
            Object[] dependencies = new Object[paramTypes.length];

            for (int i = 0; i < paramTypes.length; i++) {
                Class<?> paramType = paramTypes[i];
                System.out.println("    -> " + clazz.getSimpleName()
                        + " a besoin de " + paramType.getSimpleName());

                // APPEL RECURSIF : on cree (ou recupere) la dependance.
                // Si paramType est une interface, resolveDependency trouve l'impl.
                dependencies[i] = resolveDependency(paramType);
            }

            // --- Etape C : instancier la classe avec ses dependances ------
            // newInstance() appelle reellement le constructeur en lui passant
            // le tableau des dependances qu'on vient de resoudre.
            constructor.setAccessible(true); // au cas ou le constructeur soit prive
            Object instance = constructor.newInstance(dependencies);

            // --- Etape D : enregistrer le bean comme singleton ------------
            singletons.put(clazz, instance);
            System.out.println("    [cree] " + clazz.getSimpleName());

            return instance;

        } catch (DependencyInjectionException e) {
            // On laisse remonter nos propres exceptions telles quelles.
            throw e;
        } catch (Exception e) {
            // Toute autre erreur technique (constructeur qui plante, classe
            // abstraite, etc.) est enveloppee dans notre exception claire.
            throw new DependencyInjectionException(
                "Echec de creation du bean : " + clazz.getName(), e);
        } finally {
            // Dans tous les cas, cette classe n'est plus "en cours de creation".
            currentlyInCreation.remove(clazz);
        }
    }

    /**
     * Choisit le constructeur a utiliser pour instancier la classe.
     *
     * Regles (simplifiees par rapport a Spring, mais memes idees) :
     *   1. S'il existe un constructeur annote @Autowired, on prend celui-la.
     *   2. Sinon, s'il n'y a qu'un seul constructeur, on prend celui-la.
     *   3. Sinon (plusieurs constructeurs, aucun @Autowired) : ambigu -> erreur.
     */
    private Constructor<?> resolveConstructor(Class<?> clazz) {
        Constructor<?>[] constructors = clazz.getDeclaredConstructors();

        // Regle 1 : chercher un constructeur annote @Autowired.
        for (Constructor<?> constructor : constructors) {
            if (constructor.isAnnotationPresent(Autowired.class)) {
                return constructor;
            }
        }

        // Regle 2 : un seul constructeur -> pas d'ambiguite, on le prend.
        if (constructors.length == 1) {
            return constructors[0];
        }

        // Regle 3 : plusieurs constructeurs et aucun @Autowired -> on ne sait
        // pas lequel choisir. On exige une annotation explicite.
        throw new DependencyInjectionException(
            "Classe " + clazz.getName() + " : plusieurs constructeurs, "
            + "ajoutez @Autowired sur celui a utiliser.");
    }

    /**
     * Resout une dependance d'un type donne (classe concrete OU interface).
     */
    private Object resolveDependency(Class<?> type) {
        // Cas 1 : c'est une classe concrete qu'on sait instancier directement.
        if (!type.isInterface()) {
            return getOrCreateBean(type);
        }

        // Cas 2 : c'est une INTERFACE. On cherche une classe @Component qui
        // l'implemente, puis on cree CETTE implementation.
        for (Class<?> candidate : componentClasses) {
            if (type.isAssignableFrom(candidate)) {
                // isAssignableFrom = "est-ce que 'candidate' est un sous-type de 'type' ?"
                return getOrCreateBean(candidate);
            }
        }

        throw new DependencyInjectionException(
            "Aucune implementation trouvee pour l'interface : " + type.getName());
    }

    /**
     * Cherche dans les beans deja crees une instance compatible avec 'type'
     * (utile quand getBean est appele avec une interface).
     */
    private Object findByType(Class<?> type) {
        for (Map.Entry<Class<?>, Object> entry : singletons.entrySet()) {
            if (type.isAssignableFrom(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }

    /**
     * Petit utilitaire : liste les noms de tous les beans actifs.
     * Pratique pour verifier ce que le conteneur a cree.
     */
    public List<String> getBeanNames() {
        List<String> names = new ArrayList<>();
        for (Class<?> clazz : singletons.keySet()) {
            names.add(clazz.getSimpleName());
        }
        return names;
    }
}
