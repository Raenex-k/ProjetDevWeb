package com.cacf.happy.dto;

// IMPORTS A ADAPTER : jakarta.validation.* ou javax.validation.*
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

/**
 * ============================================================================
 *  GeoLocationRequestDTO  --  corps des requetes POST et PATCH
 * ============================================================================
 *
 * UN SEUL DTO pour POST et PATCH : une position s'envoie toujours en entier
 * (latitude + longitude ensemble), donc les deux operations ont les memes
 * champs et les memes regles. Pas besoin de deux DTO identiques.
 *
 * customerId et deviceId ne sont PAS ici : ils sont dans l'URL (@PathParam).
 *
 * C'est ce DTO qui porte la VALIDATION (jamais l'entity). @Valid dans la
 * Resource declenche ces controles avant tout traitement -> 400 si invalide.
 * ============================================================================
 */
@Getter
@Setter
public class GeoLocationRequestDTO {

    /** Latitude : obligatoire, entre -90 et +90 (bornes incluses). */
    @NotNull(message = "La latitude est obligatoire")
    @DecimalMin(value = "-90.0", message = "Latitude minimale : -90")
    @DecimalMax(value = "90.0", message = "Latitude maximale : 90")
    private Double latitude;

    /** Longitude : obligatoire, entre -180 et +180 (bornes incluses). */
    @NotNull(message = "La longitude est obligatoire")
    @DecimalMin(value = "-180.0", message = "Longitude minimale : -180")
    @DecimalMax(value = "180.0", message = "Longitude maximale : 180")
    private Double longitude;

    /**
     * Precision GPS en metres. OPTIONNELLE (pas de @NotNull) : tous les
     * appareils ne la fournissent pas.
     * A CONFIRMER avec l'equipe mobile : si l'app ne l'envoie jamais,
     * on peut supprimer ce champ (et la colonne accuracy_meters).
     */
    private Double accuracy;
}
