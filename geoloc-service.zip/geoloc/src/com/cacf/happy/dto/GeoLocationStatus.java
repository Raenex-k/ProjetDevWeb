package com.cacf.happy.dto;

/**
 * Statut renvoye dans la reponse POST / PATCH.
 *   CREATED -> une position vient d'etre creee (POST)
 *   UPDATED -> une position existante vient d'etre mise a jour (PATCH)
 */
public enum GeoLocationStatus {
    CREATED,
    UPDATED
}
