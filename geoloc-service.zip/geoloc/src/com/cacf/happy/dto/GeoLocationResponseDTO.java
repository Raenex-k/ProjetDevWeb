package com.cacf.happy.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * ============================================================================
 *  GeoLocationResponseDTO  --  reponse renvoyee apres POST et PATCH
 * ============================================================================
 *
 * Confirme au mobile que la position a bien ete enregistree.
 * Le status precise s'il s'agit d'une creation (CREATED) ou d'une mise a
 * jour (UPDATED).
 * ============================================================================
 */
@Getter
@Setter
@Builder
public class GeoLocationResponseDTO {

    /** Confirmation de l'identifiant client. */
    private String customerId;

    /** Confirmation de l'identifiant device. */
    private String deviceId;

    /** Horodatage serveur d'enregistrement (= lastUpdated en base). */
    private LocalDateTime savedAt;

    /** CREATED (POST) ou UPDATED (PATCH). Positionne par le Service. */
    private GeoLocationStatus status;
}
