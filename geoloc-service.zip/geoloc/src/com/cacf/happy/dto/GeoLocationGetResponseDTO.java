package com.cacf.happy.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * ============================================================================
 *  GeoLocationGetResponseDTO  --  reponse renvoyee par le GET
 * ============================================================================
 *
 * Contient l'ensemble des informations de position, pour les autres
 * applications du SI CACF qui consultent la position d'un device.
 * ============================================================================
 */
@Getter
@Setter
@Builder
public class GeoLocationGetResponseDTO {

    private String customerId;
    private String deviceId;

    /** Derniere latitude connue. */
    private Double latitude;

    /** Derniere longitude connue. */
    private Double longitude;

    /** Horodatage serveur d'enregistrement (= lastUpdated en base). */
    private LocalDateTime savedAt;

    /** Precision GPS en metres. Peut etre null. */
    private Double accuracyMeters;
}
