package com.cacf.happy.repository;

import com.cacf.happy.entity.CustomerLocation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * ============================================================================
 *  GeoLocationRepository  --  acces a la table customer_location
 * ============================================================================
 *
 * Interface : Spring Data JPA genere l'implementation tout seul.
 * JpaRepository<CustomerLocation, String> -> entity geree + type de la cle
 * primaire (customerId est un String).
 *
 * On cherche par customerId (la cle primaire) : un client = une position.
 * ============================================================================
 */
@Repository
public interface GeoLocationRepository extends JpaRepository<CustomerLocation, String> {

    /** SELECT * FROM customer_location WHERE customer_id = ? */
    Optional<CustomerLocation> findByCustomerId(String customerId);

    /** SELECT COUNT(*) > 0 ... WHERE customer_id = ? (test de doublon pour le POST) */
    boolean existsByCustomerId(String customerId);

    /** DELETE FROM customer_location WHERE customer_id = ? (RGPD) */
    void deleteByCustomerId(String customerId);
}
