package com.cacf.happy.resource;

import com.cacf.happy.dto.GeoLocationGetResponseDTO;
import com.cacf.happy.dto.GeoLocationRequestDTO;
import com.cacf.happy.dto.GeoLocationResponseDTO;
import com.cacf.happy.service.GeoLocationService;

// ⚠️ IMPORTS A ADAPTER : jakarta.ws.rs.* ou javax.ws.rs.* selon le projet.
//    Regarde AccountResource / CustomerResource et copie LEURS imports.
import jakarta.validation.Valid;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;

// ⚠️ IMPORTS des annotations de securite CACF (package security.access.control) :
// import com.cacf.happy.security.access.control.annotation.AccessControl;
// import com.cacf.happy.security.access.control.annotation.AccessControlCustomerId;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ============================================================================
 *  GeoLocationResource  --  la couche HTTP (JAX-RS / Apache CXF)
 * ============================================================================
 *
 * 4 endpoints, tous sur le meme chemin, seul le verbe HTTP change :
 *   POST   -> creer la position
 *   PATCH  -> mettre a jour
 *   GET    -> consulter
 *   DELETE -> supprimer (RGPD)
 *
 * SECURITE (comme AccountResource / CustomerResource) :
 *   @AccessControl(function = "ND")   -> sur la methode : droit d'appeler
 *   @AccessControlCustomerId          -> sur le param customerId : compare avec le JWT
 *   -> l'AccessControlInterceptor fait tout automatiquement, aucune verif a coder.
 *
 * La Resource ne fait AUCUNE try/catch : les exceptions du Service remontent
 * vers ExceptionUtil (gestionnaire global) qui renvoie le bon code HTTP.
 *
 * @Valid declenche la validation du DTO (400 si invalide) avant le Service.
 * ============================================================================
 */
@Component
@Path("/customers/{customerId}/devices/{deviceId}/position")
public class GeoLocationResource {

    private final GeoLocationService geoLocationService;

    @Autowired
    public GeoLocationResource(GeoLocationService geoLocationService) {
        this.geoLocationService = geoLocationService;
    }

    /** POST : creer la premiere position. */
    @POST
    // @AccessControl(function = "ND")
    public Response createPosition(
            /* @AccessControlCustomerId */ @PathParam("customerId") String customerId,
            @PathParam("deviceId") String deviceId,
            @HeaderParam("X-JWT-Assertion") String jwtToken,
            @Valid GeoLocationRequestDTO dto) {

        GeoLocationResponseDTO response =
                geoLocationService.createPosition(customerId, deviceId, dto);
        return Response.ok(response).build(); // HTTP 200
    }

    /** PATCH : mettre a jour la position existante. */
    @PATCH
    // @AccessControl(function = "ND")
    public Response updatePosition(
            /* @AccessControlCustomerId */ @PathParam("customerId") String customerId,
            @PathParam("deviceId") String deviceId,
            @HeaderParam("X-JWT-Assertion") String jwtToken,
            @Valid GeoLocationRequestDTO dto) {

        GeoLocationResponseDTO response =
                geoLocationService.updatePosition(customerId, deviceId, dto);
        return Response.ok(response).build(); // HTTP 200
    }

    /** GET : consulter la position. */
    @GET
    // @AccessControl(function = "ND")
    public Response getPosition(
            /* @AccessControlCustomerId */ @PathParam("customerId") String customerId,
            @PathParam("deviceId") String deviceId,
            @HeaderParam("X-JWT-Assertion") String jwtToken) {

        GeoLocationGetResponseDTO response =
                geoLocationService.getPosition(customerId, deviceId);
        return Response.ok(response).build(); // HTTP 200
    }

    /** DELETE : supprimer la position (RGPD, droit a l'effacement). */
    @DELETE
    // @AccessControl(function = "ND")
    public Response deletePosition(
            /* @AccessControlCustomerId */ @PathParam("customerId") String customerId,
            @PathParam("deviceId") String deviceId,
            @HeaderParam("X-JWT-Assertion") String jwtToken) {

        geoLocationService.deletePosition(customerId, deviceId);
        return Response.noContent().build(); // HTTP 204
    }
}
