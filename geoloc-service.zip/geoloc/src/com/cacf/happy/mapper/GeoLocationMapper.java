package com.cacf.happy.mapper;

import com.cacf.happy.dto.GeoLocationGetResponseDTO;
import com.cacf.happy.dto.GeoLocationRequestDTO;
import com.cacf.happy.dto.GeoLocationResponseDTO;
import com.cacf.happy.entity.CustomerLocation;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * ============================================================================
 *  GeoLocationMapper  --  conversions entre entity et DTO (MapStruct)
 * ============================================================================
 *
 * MapStruct genere l'implementation a la compilation. On declare juste
 * les signatures.
 *
 * Ici une simple INTERFACE suffit (pas de classe abstraite) car il n'y a
 * pas de logique @AfterMapping : lastUpdated est gere par l'entity elle-meme
 * (@PrePersist / @PreUpdate), pas par le mapper.
 *
 * componentModel = "spring" -> le mapper devient un bean injectable via @Autowired.
 * ADAPTE componentModel si le projet utilise une autre convention.
 * ============================================================================
 */
@Mapper(componentModel = "spring")
public interface GeoLocationMapper {

    /**
     * DTO de requete -> Entity.
     * Ne mappe QUE les champs du body (latitude, longitude, accuracy).
     * customerId et deviceId sont positionnes par le Service depuis l'URL.
     * lastUpdated est rempli par l'entity (@PrePersist).
     */
    @Mapping(source = "accuracy", target = "accuracyMeters")
    @Mapping(target = "customerId", ignore = true)
    @Mapping(target = "deviceId", ignore = true)
    @Mapping(target = "lastUpdated", ignore = true)
    CustomerLocation toEntity(GeoLocationRequestDTO dto);

    /**
     * Entity -> reponse POST / PATCH.
     * Renomme lastUpdated en savedAt. Le status est positionne par le Service.
     */
    @Mapping(source = "lastUpdated", target = "savedAt")
    @Mapping(target = "status", ignore = true)
    GeoLocationResponseDTO toDto(CustomerLocation entity);

    /**
     * Entity -> reponse GET (toutes les infos de position).
     * Renomme lastUpdated en savedAt.
     */
    @Mapping(source = "lastUpdated", target = "savedAt")
    GeoLocationGetResponseDTO toGetDto(CustomerLocation entity);
}
