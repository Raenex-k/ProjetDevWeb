package com.cacf.happy.entity;

// ============================================================================
//  IMPORTS A ADAPTER : jakarta.* (Spring Boot 3) ou javax.* (Spring Boot 2)
//  Regarde DeviceTokenEntity / AccountEntity et copie LEURS imports.
// ============================================================================
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * ============================================================================
 *  CustomerLocation  --  entity JPA de la table customer_location
 * ============================================================================
 *
 * Une instance = une ligne. Un champ = une colonne.
 *
 * CLE PRIMAIRE : customerId seul (un client = un device = une position).
 * deviceId est une simple colonne : on le stocke, mais il n'est pas dans la cle.
 *
 * lastUpdated est rempli cote serveur par @PrePersist / @PreUpdate,
 * jamais par le mobile. C'est la seule date conservee (pas de capturedAt :
 * le mobile n'envoie que la derniere position au retour du reseau).
 *
 * Annotations Lombok : ADAPTE-les a celles de DeviceTokenEntity.
 *   Si DeviceTokenEntity utilise @Data, remplace @Getter/@Setter par @Data.
 * ============================================================================
 */
@Entity
@Table(name = "customer_location")
@Getter
@Setter
@NoArgsConstructor   // constructeur vide : OBLIGATOIRE pour JPA
@AllArgsConstructor  // constructeur complet : requis par @Builder
@Builder             // permet CustomerLocation.builder().customerId(...).build()
public class CustomerLocation {

    /** Cle primaire : le client. Vient de l'URL (jamais du body). */
    @Id
    @Column(name = "customer_id", nullable = false)
    private String customerId;

    /** L'appareil concerne. Simple colonne. Vient de l'URL. */
    @Column(name = "device_id", nullable = false)
    private String deviceId;

    /** Latitude GPS (Nord/Sud), entre -90 et +90. Fournie par le mobile. */
    @Column(name = "latitude", nullable = false)
    private Double latitude;

    /** Longitude GPS (Est/Ouest), entre -180 et +180. Fournie par le mobile. */
    @Column(name = "longitude", nullable = false)
    private Double longitude;

    /**
     * Horodatage serveur de derniere ecriture. Rempli automatiquement
     * (voir onCreate / onUpdate). Renvoye comme "savedAt" dans les reponses.
     */
    @Column(name = "last_updated", nullable = false)
    private LocalDateTime lastUpdated;

    /** Precision GPS en metres. NULLABLE : pas fournie par tous les appareils. */
    @Column(name = "accuracy_meters")
    private Double accuracyMeters;

    // ------------------------------------------------------------------------
    //  Callbacks JPA : remplir lastUpdated tout seul (comme DeviceTokenEntity)
    // ------------------------------------------------------------------------

    /** Appelee par JPA juste avant le 1er INSERT (creation). */
    @PrePersist
    public void onCreate() {
        this.lastUpdated = LocalDateTime.now();
    }

    /** Appelee par JPA juste avant chaque UPDATE (mise a jour). */
    @PreUpdate
    public void onUpdate() {
        this.lastUpdated = LocalDateTime.now();
    }
}
