package com.cacf.happy.service;

import com.cacf.happy.dto.GeoLocationGetResponseDTO;
import com.cacf.happy.dto.GeoLocationRequestDTO;
import com.cacf.happy.dto.GeoLocationResponseDTO;
import com.cacf.happy.dto.GeoLocationStatus;
import com.cacf.happy.entity.CustomerLocation;
import com.cacf.happy.mapper.GeoLocationMapper;
import com.cacf.happy.repository.GeoLocationRepository;

// ⚠️ IMPORTS A ADAPTER aux vraies classes du projet CACF :
//    - DeviceTokenRepository (existe deja dans le projet)
//    - les exceptions (HappyNotFoundException, ClientError...) du package util/error
// import com.cacf.happy.repository.DeviceTokenRepository;
// import com.cacf.happy.util.error.HappyNotFoundException;
// import com.cacf.happy.util.error.ClientError;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * ============================================================================
 *  GeoLocationService  --  logique metier de la geolocalisation
 * ============================================================================
 *
 * Contient toutes les regles metier. La Resource ne fait qu'appeler ce service.
 * Aucune try/catch ici : les exceptions remontent vers ExceptionUtil (le
 * gestionnaire global du projet) qui renvoie le bon code HTTP.
 *
 * SECURITE : la coherence customerId URL == JWT est deja assuree en amont par
 * l'AccessControlInterceptor (via @AccessControl + @AccessControlCustomerId sur
 * la Resource). Rien a verifier ici pour ca.
 * ============================================================================
 */
@Service
public class GeoLocationService {

    private final GeoLocationRepository geoLocationRepository;
    private final GeoLocationMapper geoLocationMapper;
    private final GeoLocationConsentService consentService;

    // ⚠️ A DECOMMENTER si la verif "device enregistre" est retenue (bonus securite).
    // private final DeviceTokenRepository deviceTokenRepository;

    @Autowired
    public GeoLocationService(GeoLocationRepository geoLocationRepository,
                              GeoLocationMapper geoLocationMapper,
                              GeoLocationConsentService consentService
                              /*, DeviceTokenRepository deviceTokenRepository */) {
        this.geoLocationRepository = geoLocationRepository;
        this.geoLocationMapper = geoLocationMapper;
        this.consentService = consentService;
        // this.deviceTokenRepository = deviceTokenRepository;
    }

    // ========================================================================
    //  CREATE (POST)
    // ========================================================================
    public GeoLocationResponseDTO createPosition(String customerId, String deviceId,
                                                 GeoLocationRequestDTO dto) {

        // 1. Consentement RGPD : le client a-t-il autorise la geoloc ?
        if (!consentService.hasConsent(customerId)) {
            throw buildForbidden("Consentement de geolocalisation non accorde");
        }

        // 2. (BONUS, a confirmer) L'appareil est-il enregistre dans device_tokens ?
        // if (!deviceTokenRepository.existsByCustomerIdAndDeviceId(customerId, deviceId)) {
        //     throw buildNotFound("Appareil inconnu pour ce client");
        // }

        // 3. Doublon : une position existe-t-elle deja ? -> POST interdit (409)
        if (geoLocationRepository.existsByCustomerId(customerId)) {
            throw buildConflict("Une position existe deja pour ce client, utiliser PATCH");
        }

        // 4. DTO -> Entity. Le mapper mappe lat/lng/accuracy ; le Service pose
        //    customerId et deviceId depuis l'URL. lastUpdated -> @PrePersist.
        CustomerLocation entity = geoLocationMapper.toEntity(dto);
        entity.setCustomerId(customerId);
        entity.setDeviceId(deviceId);

        // 5. Sauvegarde (INSERT). lastUpdated est rempli par @PrePersist.
        CustomerLocation saved = geoLocationRepository.save(entity);

        // 6. Entity -> DTO de reponse, avec status = CREATED.
        GeoLocationResponseDTO response = geoLocationMapper.toDto(saved);
        response.setStatus(GeoLocationStatus.CREATED);
        return response;
    }

    // ========================================================================
    //  UPDATE (PATCH)
    // ========================================================================
    public GeoLocationResponseDTO updatePosition(String customerId, String deviceId,
                                                 GeoLocationRequestDTO dto) {

        // 1. Consentement RGPD.
        if (!consentService.hasConsent(customerId)) {
            throw buildForbidden("Consentement de geolocalisation non accorde");
        }

        // 2. La position doit deja exister -> sinon 404 (utiliser POST d'abord).
        CustomerLocation entity = geoLocationRepository.findByCustomerId(customerId)
                .orElseThrow(() -> buildNotFound("Aucune position pour ce client"));

        // 3. Mise a jour des champs GPS. lastUpdated -> @PreUpdate.
        entity.setLatitude(dto.getLatitude());
        entity.setLongitude(dto.getLongitude());
        entity.setAccuracyMeters(dto.getAccuracy());
        entity.setDeviceId(deviceId);

        // 4. Sauvegarde (UPDATE).
        CustomerLocation saved = geoLocationRepository.save(entity);

        // 5. Reponse avec status = UPDATED.
        GeoLocationResponseDTO response = geoLocationMapper.toDto(saved);
        response.setStatus(GeoLocationStatus.UPDATED);
        return response;
    }

    // ========================================================================
    //  GET
    // ========================================================================
    public GeoLocationGetResponseDTO getPosition(String customerId, String deviceId) {

        CustomerLocation entity = geoLocationRepository.findByCustomerId(customerId)
                .orElseThrow(() -> buildNotFound("Aucune position pour ce client"));

        return geoLocationMapper.toGetDto(entity);
    }

    // ========================================================================
    //  DELETE (RGPD, droit a l'effacement)
    // ========================================================================
    @Transactional  // requis pour une methode deleteBy... derivee
    public void deletePosition(String customerId, String deviceId) {

        if (!geoLocationRepository.existsByCustomerId(customerId)) {
            throw buildNotFound("Aucune position pour ce client");
        }
        geoLocationRepository.deleteByCustomerId(customerId);
    }

    // ========================================================================
    //  HELPERS D'EXCEPTION
    //  ⚠️ A REMPLACER par les vraies exceptions du projet (util/error) :
    //     HappyNotFoundException, ClientError, etc.
    //     Ici on met des RuntimeException pour que le code compile en l'etat.
    // ========================================================================
    private RuntimeException buildForbidden(String msg) {
        // return new ClientError(403, msg);
        return new RuntimeException("403 - " + msg);
    }

    private RuntimeException buildNotFound(String msg) {
        // return new HappyNotFoundException(msg);
        return new RuntimeException("404 - " + msg);
    }

    private RuntimeException buildConflict(String msg) {
        // return new ClientError(409, msg);
        return new RuntimeException("409 - " + msg);
    }
}
