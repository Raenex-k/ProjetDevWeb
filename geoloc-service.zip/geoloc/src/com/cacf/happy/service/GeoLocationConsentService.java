package com.cacf.happy.service;

/**
 * ============================================================================
 *  GeoLocationConsentService  --  lecture du consentement geoloc
 * ============================================================================
 *
 *  ⚠️  A CONFIRMER AVEC LE TECH LEAD  ⚠️
 *
 * Deux points restent a valider avant d'implementer cette classe :
 *
 *   1. Est-ce que gerer le consentement geoloc est dans TON perimetre,
 *      ou tu dois juste le LIRE pour verifier avant de stocker une position ?
 *
 *   2. OU stocker le consentement geoloc :
 *        Option A (recommandee) -> table dediee "geolocation_consent"
 *                                  + ce service dedie
 *                                  -> aucune modification du code notif
 *        Option B -> reutiliser la table Preference avec un code "GEOLOCATION"
 *                    -> MAIS il faut corriger le findByCustomerId du service
 *                       notif pour qu'il filtre par notifCode, sinon il casse
 *                       (il remonterait 2 lignes -> NonUniqueResultException).
 *
 * Cette interface represente la solution A : un service geoloc dedie.
 * Une fois la decision prise, on l'implemente (table dediee ou appel a
 * PreferenceService modifie).
 *
 * Le Service geoloc n'a besoin que de LIRE (hasConsent) pour verifier avant
 * de stocker. L'ecriture du consentement (setConsent) est peut-etre geree
 * ailleurs -> a confirmer aussi.
 * ============================================================================
 */
public interface GeoLocationConsentService {

    /**
     * Le client a-t-il donne son consentement de geolocalisation ?
     *
     * IMPORTANT (RGPD) : si aucun consentement n'existe, retourner false.
     * Le consentement doit etre explicite, jamais suppose.
     *
     * @param customerId le client
     * @return true si consentement donne, false sinon (ou si absent)
     */
    boolean hasConsent(String customerId);
}
