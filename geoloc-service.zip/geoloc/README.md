# Service de Geolocalisation - code complet

Ce dossier contient toutes les classes du service de geolocalisation pour
`app-notifications-ms`, dans l'ordre des couches, avec les decisions qu'on a
validees.

## Structure

```
com/cacf/happy/
├── entity/
│   └── CustomerLocation.java          Entity JPA (table customer_location)
├── dto/
│   ├── GeoLocationRequestDTO.java     Corps POST + PATCH (avec validation)
│   ├── GeoLocationResponseDTO.java    Reponse POST + PATCH
│   ├── GeoLocationGetResponseDTO.java Reponse GET
│   └── GeoLocationStatus.java         Enum CREATED / UPDATED
├── mapper/
│   └── GeoLocationMapper.java         MapStruct (entity <-> DTO)
├── repository/
│   └── GeoLocationRepository.java     Acces table customer_location
├── service/
│   ├── GeoLocationService.java        Logique metier (les 4 operations)
│   └── GeoLocationConsentService.java Interface consentement (a implementer)
└── resource/
    └── GeoLocationResource.java       Les 4 endpoints HTTP
```

## Ordre de lecture / d'integration

De la base vers le HTTP : Entity -> DTO -> Mapper -> Repository -> Service -> Resource.
Teste apres chaque couche (ex: apres l'entity, lance l'app et verifie que la
table customer_location se cree via ddl-auto=update).

## Les 4 endpoints

```
POST   /customers/{customerId}/devices/{deviceId}/position   creer   (200)
PATCH  /customers/{customerId}/devices/{deviceId}/position   modifier (200)
GET    /customers/{customerId}/devices/{deviceId}/position   lire    (200)
DELETE /customers/{customerId}/devices/{deviceId}/position   effacer (204)
```

## Les decisions integrees

- Cle primaire = customerId seul (un client = un device = une position).
- deviceId = simple colonne (pas dans la cle).
- Pas de capturedAt : le mobile n'envoie que la derniere position au retour du
  reseau. Une seule date, cote serveur (lastUpdated, remplie par @PrePersist/@PreUpdate).
- Un seul DTO de requete partage par POST et PATCH (memes champs, memes regles).
- Securite : @AccessControl + @AccessControlCustomerId (interceptor CACF).
  La coherence customerId URL == JWT est automatique, rien a coder.
- Erreurs : 400 (validation), 403 (consentement), 404 (introuvable),
  409 (doublon au POST), 204 (delete).

## ⚠️ POINTS A ADAPTER dans le code (marques par des commentaires)

1. **Les imports jakarta / javax**
   Selon la version de Spring Boot. Regarde un fichier existant
   (DeviceTokenEntity, AccountResource) et copie ses imports.

2. **Les annotations Lombok de l'entity**
   Copie celles de DeviceTokenEntity (si c'est @Data, remplace @Getter/@Setter).

3. **Les exceptions du Service**
   Remplace les RuntimeException temporaires par les vraies exceptions du
   projet (HappyNotFoundException, ClientError...) du package util/error.

4. **Les annotations de securite** (@AccessControl, @AccessControlCustomerId)
   Actuellement en commentaire. Decommente-les et ajuste function="ND" (ou la
   vraie valeur) en copiant ce que fait AccountResource.

## ⚠️ POINTS A CONFIRMER AVEC LE TECH LEAD (bloquants pour finaliser)

1. **Le consentement geoloc**
   - Est-ce dans ton perimetre (le gerer) ou tu dois juste le LIRE ?
   - Table dediee (recommande) ou reutiliser Preference ?
     Si Preference : il faut corriger le findByCustomerId du service notif
     (sinon il casse avec 2 lignes -> NonUniqueResultException).
   -> GeoLocationConsentService est une interface prete a implementer selon la reponse.

2. **La verif "device enregistre"** (bonus securite)
   Actuellement en commentaire dans le Service. A activer si le tech lead
   veut verifier que le deviceId existe dans device_tokens avant de stocker.

3. **Le champ accuracy**
   Nullable pour l'instant. Si l'app mobile ne l'envoie jamais, on peut
   supprimer le champ (DTO + entity + colonne).

## Rappel

Ce code compile en l'etat une fois les imports adaptes, SAUF
GeoLocationConsentService qui est une interface a implementer (selon la
decision consentement). En attendant, tu peux mettre une implementation
temporaire qui retourne true pour tester le reste du flux.
